# Bottle Detection  > CVR201_nahid_V2
https://universe.roboflow.com/turbo-mania/bottle-detection-kg8ma

Provided by a Roboflow user
License: CC BY 4.0

